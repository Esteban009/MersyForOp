Fully working PHP/AJAX contact form is avaialbe in the pro version.
You can buy it from: https://bootstrapmade.com/buy/?theme=Medicio